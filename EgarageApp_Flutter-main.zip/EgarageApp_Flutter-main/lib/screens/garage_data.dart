class Data {

  List allstores = [
    {
      "name": "Ather Space - Electric Scooter EC",
      "image":"https://www.rushlane.com/wp-content/uploads/2021/02/ather-ahmedabad-showroom-launch-2-600x338.jpg",
      "lat": 23.02997724910574,
      "lng": 72.54253148947657,
      "distance": 0,
      "phone" : "07406892666",
      "address" : "Shop No. 01, Ground floor, 3rd Eye Vision Opp. Shivalik Plaza, near AMA, Panjrapole CharRasta, Ahmedabad, Gujarat 380006",
    },


    {

      "name": "Ather Service Center- Kataria Green",
      "image": "https://content.jdmagicbox.com/comp/ahmedabad/f6/079pxx79.xx79.221212151246.v9f6/catalogue/-8rmatw3ip3.jpg?clr=",
      "lat": 23.047742709465705,
      "lng": 72.5711434684148,
      "distance": 0,
      "phone" : "07406892666",
      "address" : "C/6 , Ashwarath complex Near municipal corporation zonal office, Usmanpura, Ahmedabad, Gujarat 380013",
    },

    {

      "name": "Ola Experience Centre ",
      "image": "https://www.financialexpress.com/wp-content/uploads/2022/09/Ola-Experience-Centre-2.jpg",
      "lat": 22.986256393664416,
      "lng": 72.62585877483369,
      "distance": 0,
      "phone" : "987653483",
      "address" : "Suncor Plaza, Shop no 1 & 2, Suncor plaza Jasoda chowkdi, opposite Brts stand, Ahmedabad, Gujarat 380050"
    },
  ];
}
