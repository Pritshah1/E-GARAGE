package com.example.egarage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
